#include <Arduino.h>

#define LED_PIN PA0
#define ADC_PIN PA1
#define SERVO_PIN PA4

unsigned long lastPrintTime = 0;

// Manual PWM untuk servo (1000-2000us)
void setServoAngle(int angle) {
    // Convert angle (0-180) to pulse width (1000-2000 microseconds)
    int pulseWidth = map(angle, 0, 180, 1000, 2000);
    
    digitalWrite(SERVO_PIN, HIGH);
    delayMicroseconds(pulseWidth);
    digitalWrite(SERVO_PIN, LOW);
    delayMicroseconds(20000 - pulseWidth);  // 20ms period
}

void setup() {
    Serial.begin(115200);
    delay(2000);
    Serial.println("Program 06: SG90 Servo + LED Control - Manual PWM\n");
    
    pinMode(LED_PIN, OUTPUT);
    pinMode(SERVO_PIN, OUTPUT);
    digitalWrite(SERVO_PIN, LOW);
    analogReadResolution(12);
    
    // Test servo
    Serial.println("Testing servo: 0° → 90° → 180°");
    for (int i = 0; i < 50; i++) setServoAngle(0);      // 1 second at 0°
    delay(500);
    
    for (int i = 0; i < 50; i++) setServoAngle(90);     // 1 second at 90°
    delay(500);
    
    for (int i = 0; i < 50; i++) setServoAngle(180);    // 1 second at 180°
    delay(500);
    
    for (int i = 0; i < 50; i++) setServoAngle(90);     // Center
    delay(500);
    
    Serial.println("✓ Servo test complete\n");
    Serial.println("Ready for potentiometer control...\n");
}

void loop() {
    // Read potentiometer
    int adc = analogRead(ADC_PIN);
    int pwm = map(adc, 0, 4095, 0, 255);
    int angle = map(adc, 0, 4095, 0, 180);
    
    // Update LED
    analogWrite(LED_PIN, pwm);
    
    // Update Servo dengan manual PWM (20ms period)
    setServoAngle(angle);
    
    // Print setiap 200ms
    if (millis() - lastPrintTime >= 200) {
        lastPrintTime = millis();
        
        float voltage = (adc / 4095.0) * 5.0;
        float brightness = (pwm / 255.0) * 100.0;
        
        Serial.print("ADC: ");
        Serial.print(adc);
        Serial.print(" | Voltage: ");
        Serial.print(voltage, 2);
        Serial.print("V | PWM: ");
        Serial.print(pwm);
        Serial.print(" | LED: ");
        Serial.print(brightness, 1);
        Serial.print("% | Servo: ");
        Serial.print(angle);
        Serial.println("°");
    }
}
